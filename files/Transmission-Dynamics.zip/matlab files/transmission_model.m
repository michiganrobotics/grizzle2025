% Function to compute the transmission dynamics
% Input params:
%    q - generalized vector of coordinates
%   dq - generalized vector of velocity of coordinates
%   leg_flag - 'L' => Compute Transmission dynamics for Left leg, 'R' => Compute Transmission dynamics for right leg
%   indep_vars_flag_L - Independent variables for left leg.
%   indep_vars_flag_R - Independent variables for right leg.
%      indep_vars_flag can be one of - 
%         (i) 'qLA,qLS,qmLS'
%        (ii) 'qLA,qLS,Bspring'
%       (iii) 'qLA,qmLS,Bspring'
%        (iv) 'qLA,qLS'  => Bspring=0
%         (v) 'qLA,qmLS' => Bspring=0
function [KE,PE,THETA_MLA,THETA_MLS,THETA_KNEE,THETA_DTHIGH,THETA_BSPRING,THETA_MLA_STEPDOWN,THETA_LS,THETA_LA,THETA_TOR]=transmission_model(q,dq,leg_flag,indep_vars_flag_L,indep_vars_flag_R)

% Default parameters for this function
if(nargin == 0)
    syms qLA_L qLS_L qBsp_L qLA_R qLS_R qBsp_R qTor ;
    syms dqLA_L dqLS_L dqBsp_L dqLA_R dqLS_R dqBsp_R dqTor ;
    q = [qLA_L qLS_L qBsp_L qLA_R qLS_R qBsp_R qTor] ;
    dq =[dqLA_L dqLS_L dqBsp_L dqLA_R dqLS_R dqBsp_R dqTor] ;
    leg_flag = 'L' ;
    indep_vars_flag_L = 'qLA,qLS,Bspring' ;
    indep_vars_flag_R = 'qLA,qLS,Bspring' ;
end

if(leg_flag~='L' && leg_flag~='R')
    disp('invalid leg_flag passed to "symbolic_transmission_model" - function paused'); pause ;
end
if (~strcmp(indep_vars_flag_L,'qLA,qLS,qmLS') && ~strcmp(indep_vars_flag_L,'qLA,qLS,Bspring') && ~strcmp(indep_vars_flag_L,'qLA,qmLS,Bspring') && ~strcmp(indep_vars_flag_L,'qLA,qLS') && ~strcmp(indep_vars_flag_L,'qLA,qmLS'))
  disp('invalid indep_flag passed to "transmission_model" - function paused'); pause ;
end
if (~strcmp(indep_vars_flag_R,'qLA,qLS,qmLS') && ~strcmp(indep_vars_flag_R,'qLA,qLS,Bspring') && ~strcmp(indep_vars_flag_R,'qLA,qmLS,Bspring') && ~strcmp(indep_vars_flag_R,'qLA,qLS') && ~strcmp(indep_vars_flag_R,'qLA,qmLS'))
  disp('invalid indep_flag passed to "transmission_model" - function paused'); pause ;
end

if(leg_flag=='L')
    indep_vars_flag = indep_vars_flag_L ;
else
    indep_vars_flag = indep_vars_flag_R ;
end

%==================================================================
% Solve for relationships between the elements of the transmission
%==================================================================

% Angular position variables, where A, B, C and D refer to the the differentials
% and q refers to the controlled variables and radXX = radius of the
% pulley.

syms Athigh Bthigh Cthigh Dthigh radAthigh radBthigh radDthigh
syms Ashin Bshin Cshin Dshin radAshin radBshin radCshin radDshin
syms Aspring Bspring Cspring Dspring radAspring radBspring radCspring radDspring
syms pulleyMLSstepdown pulleyMLAstepdown radpulleyMLSstepdown_big radpulleyMLSstepdown_small radpulleyMLAstepdown_big radpulleyMLAstepdown_small
syms qmLS qmLA  radqmLS radqmLA
syms qLS qLA

% Constraints that define the differentials
Con1thigh=radAthigh*Athigh+radBthigh*Bthigh-(radAthigh+radBthigh)*Cthigh;%=0
Con2thigh=Athigh-Bthigh+radDthigh*(1/radAthigh + 1/radBthigh)*Dthigh;%=0
Con1shin=radAshin*Ashin+radBshin*Bshin-(radAshin+radBshin)*Cshin;%=0
Con2shin=Ashin-Bshin+radDshin*(1/radAshin+1/radBshin)*Dshin;%=0
Con1spring=radAspring*Aspring+radBspring*Bspring-(radAspring+radBspring)*Cspring;%=0
Con2spring=Aspring-Bspring+radDspring*(1/radAspring+1/radBspring)*Dspring;%=0

% Constraints that define the interconnections of the differentials
ConInt1=Bthigh-Bshin;%=0  %%on same shaft
ConInt2=radCspring*Cspring+radAshin*Ashin;%=0
ConInt3=radCspring*Cspring-radAthigh*Athigh;%=0
ConInt4=radpulleyMLAstepdown_small*pulleyMLAstepdown+radBthigh*Bthigh;%=0  %%%Fig 8 here, hence a -1
ConInt5=radqmLA*qmLA-radpulleyMLAstepdown_big*pulleyMLAstepdown;%=0
ConInt6=radpulleyMLSstepdown_small*pulleyMLSstepdown+radAspring*Aspring;%=0
ConInt7=radqmLS*qmLS+radpulleyMLSstepdown_big*pulleyMLSstepdown;%=0
ConInt8=qLS+(Cshin-Cthigh)/2;%=0
ConInt9=qLA-(Cshin+Cthigh)/2;%=0

% Compute transmission with bspring if required
if (strcmp(indep_vars_flag,'qLA,qLS') || strcmp(indep_vars_flag,'qLA,qmLS'))
    Bspring=sym(0);
    dBspring=sym(0);
end

if strcmp(indep_vars_flag,'qLA,qLS,qmLS')
  S=solve(Con1thigh,Con2thigh,Con1shin,Con2shin,Con1spring,Con2spring,ConInt1,ConInt2,ConInt3,ConInt4,ConInt5,ConInt6,ConInt7,ConInt8,ConInt9,...
    'Athigh, Bthigh, Cthigh, Dthigh, Ashin, Bshin, Cshin, Dshin, Aspring, Cspring, Dspring, pulleyMLSstepdown, pulleyMLAstepdown, Bspring, qmLA');
elseif ( strcmp(indep_vars_flag,'qLA,qLS,Bspring') | strcmp(indep_vars_flag,'qLA,qLS') )
  S=solve(Con1thigh,Con2thigh,Con1shin,Con2shin,Con1spring,Con2spring,ConInt1,ConInt2,ConInt3,ConInt4,ConInt5,ConInt6,ConInt7,ConInt8,ConInt9,...
    'Athigh, Bthigh, Cthigh, Dthigh, Ashin, Bshin, Cshin, Dshin, Aspring, Cspring, Dspring, pulleyMLSstepdown, pulleyMLAstepdown, qmLS, qmLA');
elseif ( strcmp(indep_vars_flag,'qLA,qmLS,Bspring') | strcmp(indep_vars_flag,'qLA,qmLS') )
  S=solve(Con1thigh,Con2thigh,Con1shin,Con2shin,Con1spring,Con2spring,ConInt1,ConInt2,ConInt3,ConInt4,ConInt5,ConInt6,ConInt7,ConInt8,ConInt9,...
    'Athigh, Bthigh, Cthigh, Dthigh, Ashin, Bshin, Cshin, Dshin, Aspring, Cspring, Dspring, pulleyMLSstepdown, pulleyMLAstepdown, qLS, qmLA');
end

temp=fieldnames(S);
for k=1:length(temp)
  eval([char(temp(k)),'=S.',char(temp(k)),';']);
end

%==========================
% Solve for velocity terms
%==========================

syms dAthigh dBthigh dCthigh dDthigh
syms dAshin dBshin dCshin dDshin
syms dAspring dBspring dCspring dDspring
syms dpulleyMLSstepdown dpulleyMLAstepdown
syms dqmLS dqmLA
syms dqLS dqLA 

temp=fieldnames(S);
for k=1:length(temp)
  eval(['d',char(temp(k)),'=S.',char(temp(k)),';']);
  dtemp=eval(['d',char(temp(k))]);
  XX=subs(dtemp,...
    {Athigh, Bthigh, Cthigh, Dthigh, Ashin, Bshin, Cshin, Dshin, Aspring, Cspring, Dspring, pulleyMLSstepdown, pulleyMLAstepdown, qmLS, qmLA, qLA, qLS, Bspring},...
    {dAthigh, dBthigh, dCthigh, dDthigh, dAshin, dBshin, dCshin, dDshin, dAspring, dCspring, dDspring, dpulleyMLSstepdown, dpulleyMLAstepdown, dqmLS, dqmLA, dqLA, dqLS, dBspring},0);
  eval(['d',char(temp(k)),'=XX;']);
end

%=============================================================
% Kinetic Energy for the Differentials, the Step Down Pulleys,
% and the Motor Shafts
%=============================================================

syms JAthigh JBthigh JCthigh JDthigh
syms JAshin JBshin JCshin JDshin
syms JAspring JBspring JCspring JDspring
syms JpulleyMLSstepdown JpulleyMLAstepdown
syms JqmLS JqmLA

syms dqTor

dAthigh=dqTor+dAthigh;
dBthigh=dqTor+dBthigh;
dDthigh=dqTor+dDthigh;
dAshin=dqTor+dAshin;
dBshin=dqTor+dBshin;
dDshin=dqTor+dDshin;
dAspring=dqTor+dAspring;
if (strcmp(indep_vars_flag,'qLA,qLS') || strcmp(indep_vars_flag,'qLA,qmLS'))
    dBspring=sym(0) ;
else
    dBspring=dqTor+dBspring;
end
dCspring=dqTor+dCspring;
dDspring=dqTor+dDspring;
dpulleyMLSstepdown=dqTor+dpulleyMLSstepdown;
dpulleyMLAstepdown=dqTor+dpulleyMLAstepdown;
dqmLS=dqTor+dqmLS;
dqmLA=dqTor+dqmLA;

KE_internal_thigh=0.5*(JAthigh*dAthigh^2 + JBthigh*dBthigh^2 + JDthigh*dDthigh^2);
KE_internal_shin=0.5*(JAshin*dAshin^2 + JBshin*dBshin^2 + JDshin*dDshin^2);
KE_internal_spring=0.5*(JAspring*dAspring^2 + JBspring*dBspring^2+JDspring*dDspring^2);
KE_internal_step_down_pulleys=0.5*(JpulleyMLSstepdown*dpulleyMLSstepdown^2 + JpulleyMLAstepdown*dpulleyMLAstepdown^2);
KE_internal_motors=0.5*(JqmLS*dqmLS^2 + JqmLA*dqmLA^2);
KE_internal = KE_internal_thigh + KE_internal_shin + KE_internal_spring + KE_internal_step_down_pulleys + KE_internal_motors;
KE = simple(KE_internal);

%===================================================
% Define the terms associated with the spring model
%===================================================
PE = sym(0) ;

%===============================
% Solve for the returned values
%===============================
model_params;

% These lines below are to avoid the problem of evaluating a trivial expression - eval(qLS_L) complains when there is no substitution to perform.
qmLA_tmp = qmLA ;
qmLS_tmp = qmLS ;
qLA_tmp = qLA ;
qLS_tmp = qLS ;
Dthigh_tmp = Dthigh ;
Bspring_tmp = Bspring ;
pulleyMLAstepdown_tmp = pulleyMLAstepdown ;

if( strcmp(indep_vars_flag_L,'qLA,qLS,qmLS') || strcmp(indep_vars_flag_L,'qLA,qLS,Bspring') || strcmp(indep_vars_flag_L,'qLA,qmLS,Bspring') )
    n_qL = 3 ; % No. of left coordinates
else
    n_qL = 2 ; % No. of left coordinates
end
if( strcmp(indep_vars_flag_R,'qLA,qLS,qmLS') || strcmp(indep_vars_flag_R,'qLA,qLS,Bspring') || strcmp(indep_vars_flag_R,'qLA,qmLS,Bspring') )
    n_qR = 3 ; % No. of right coordinates
else
    n_qR = 2 ; % No. of right coordinates
end

if(leg_flag=='L')
    qLA=q(1) ; dqLA=dq(1) ;
    if( strcmp(indep_vars_flag_L,'qLA,qLS,qmLS') || strcmp(indep_vars_flag_L,'qLA,qLS,Bspring') || strcmp(indep_vars_flag_L,'qLA,qLS') )
        qLS=q(2) ; dqLS=dq(2) ;
    end
    if( strcmp(indep_vars_flag_L,'qLA,qmLS,Bspring') || strcmp(indep_vars_flag_L,'qLA,qmLS') )
        qmLS=q(2) ; dqmLS=dq(2) ;
    end
    if( strcmp(indep_vars_flag_L,'qLA,qLS,qmLS') )
        qmLS=q(3) ; dqmLS=dq(3) ;
    end
    if( strcmp(indep_vars_flag_L,'qLA,qLS,Bspring') || strcmp(indep_vars_flag_L,'qLA,qmLS,Bspring'))
        Bspring=q(3) ; dBspring=dq(3) ;
    end
elseif(leg_flag=='R')    
    qLA=q(n_qL+1) ; dqLA=dq(n_qL+1) ;
    if( strcmp(indep_vars_flag_R,'qLA,qLS,qmLS') || strcmp(indep_vars_flag_R,'qLA,qLS,Bspring') || strcmp(indep_vars_flag_R,'qLA,qLS') )
        qLS=q(n_qL+2) ; dqLS=dq(n_qL+2) ;
    end
    if( strcmp(indep_vars_flag_R,'qLA,qmLS,Bspring') || strcmp(indep_vars_flag_R,'qLA,qmLS') )
        qmLS=q(n_qL+2) ; dqmLS=dq(n_qL+2) ;
    end
    if( strcmp(indep_vars_flag_R,'qLA,qLS,qmLS') )
        qmLS=q(n_qL+3) ; dqmLS=dq(n_qL+3) ;
    end
    if( strcmp(indep_vars_flag_R,'qLA,qLS,Bspring') || strcmp(indep_vars_flag_R,'qLA,qmLS,Bspring'))
        Bspring=q(n_qL+3) ; dBspring=dq(n_qL+3) ;
    end
end

% vpa_truncate is used below instead of vpa to truncate any round-off errors.
% eg: with vpa, we obtain qLS = -.1435e-16*qLA_L+.3167e-1*qBsp_L+.1925*qMLS_L;
%     with vpa_truncate, we have qLS = .3167e-1*qBsp_L+.1925*qMLS_L;
% The output file sizes are smaller, and a bit more accurate with round off errors truncated.
THETA_MLA = vpa_truncate(eval(qmLA_tmp),4);
THETA_MLS = vpa_truncate(eval(qmLS_tmp),4);
THETA_KNEE = vpa_truncate(eval(pi - 2*qLS_tmp),4);
THETA_DTHIGH = vpa_truncate(eval(Dthigh_tmp),4);
THETA_BSPRING = vpa_truncate(eval(Bspring_tmp),4);
THETA_MLA_STEPDOWN = vpa_truncate(eval(pulleyMLAstepdown_tmp),4);
THETA_LS = vpa_truncate(eval(qLS_tmp),4) ;
THETA_LA = vpa_truncate(eval(qLA_tmp),4) ;
THETA_TOR = q(n_qL+n_qR+1) ; % Torso angle assumed to be at this location

KE = vpa(eval(KE),4);
PE = vpa(eval(PE),4);