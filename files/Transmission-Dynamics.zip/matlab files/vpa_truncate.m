% Function to correct roundoff errors
% Input Params:
%    x - The symbolic expression to evaluate (It is assumed that this is
%        output of eval() command, so that all numbers are in fractions 11/23
%        etc.
%    digits - No. of digits for vpa
%    tol - [default=eps] Truncate if numeric coefficients less than this value
% eg: input x = 11/2345666688889999999*qLA
%     output x_trunc = 0.
% eg: input x = 5/3*qLA, digits=4
%     output x_trunc = 1.667*qLA
function x_trunc = vpa_truncate(x, digits, tol)
    if(nargin < 3)
        tol = eps ;
    end

    tol_str = num2str(tol) ;
    match_expr = '(\d+/\d+)' ; % Match a fraction
    replace_expr = ['${vpa_truncate_comp($1,' tol_str ')}'] ; %['${vpa_truncate_comp($1)}']
    
    x_trunc_str = regexprep(char(sym(x)), match_expr, replace_expr) ;

    x_trunc = vpa(sym(x_trunc_str), digits) ;
   
end