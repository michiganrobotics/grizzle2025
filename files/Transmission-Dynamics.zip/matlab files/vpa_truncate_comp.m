% Function to compare if numeric coeff is smaller than tolerance
function ret_str = vpa_truncate_comp(val_str, tol)
    if(nargin < 2)
        tol = eps ;
    end
    if(abs(str2num(val_str)) < tol)
        ret_str = '0' ;
    else
        ret_str = val_str ;
    end
end